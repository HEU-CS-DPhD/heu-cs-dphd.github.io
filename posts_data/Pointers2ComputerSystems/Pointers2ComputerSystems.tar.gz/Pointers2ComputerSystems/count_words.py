import json
import re
from pathlib import Path

def count_chinese_characters(ipynb_path: str):
    path = Path(ipynb_path)
    if not path.exists():
        print(f"错误: 找不到文件 {ipynb_path}")
        return

    with open(path, "r", encoding="utf-8") as f:
        nb = json.load(f)

    # 匹配 CJK 统一表意文字（常用汉字区 \u4e00 - \u9fff）
    cjk_regex = re.compile(r"[\u4e00-\u9fff]")

    total_hanzi = 0
    markdown_hanzi = 0
    code_hanzi = 0
    chapter_stats = {}
    current_chapter = "引言 / 卷首"

    for cell in nb.get("cells", []):
        cell_type = cell.get("cell_type", "")
        source_lines = cell.get("source", [])
        text = "".join(source_lines)

        # 章节追踪
        for line in source_lines:
            line_s = line.strip()
            if line_s.startswith(("# 第一章", "# 第二章", "# 第三章", "# 第四章")):
                current_chapter = line_s.lstrip("# ").strip()

        count = len(cjk_regex.findall(text))
        total_hanzi += count

        if cell_type == "markdown":
            markdown_hanzi += count
        elif cell_type == "code":
            code_hanzi += count

        chapter_stats[current_chapter] = chapter_stats.get(current_chapter, 0) + count

    print("=" * 45)
    print(f"统计文件: {path.name}")
    print(f"总汉字数: {total_hanzi} 字")
    print(f"  ├─ 正文 Markdown 汉字数: {markdown_hanzi} 字")
    print(f"  └─ 代码单元格(注释/字符串)汉字数: {code_hanzi} 字")
    print("-" * 45)
    print("各章节汉字分布:")
    for chap, cnt in chapter_stats.items():
        percent = (cnt / total_hanzi * 100) if total_hanzi else 0
        print(f"  • {chap:<26}: {cnt:>5} 字 ({percent:>5.1f}%)")
    print("=" * 45)

if __name__ == "__main__":
    count_chinese_characters("main.ipynb")
