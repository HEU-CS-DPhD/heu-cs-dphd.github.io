#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    printf("[App] Start: malloc(32) x 10 in a loop...\n");
    fflush(stdout);
    for (int i = 0; i < 10; i++) {
        void *p = malloc(32);
        (void)p;
    }
    printf("[App] Done: 10 small mallocs finished.\n");
    return 0;
}
