#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    // 获取 SP 指针
    void *sp;
    __asm__("mov %%rsp, %0" : "=r"(sp));
    printf("[App] Stack pointer (RSP) = %p\n", sp);

    printf("[App] Requesting 1MB large memory (exceeds MMAP_THRESHOLD)...\n");
    void *p = malloc(1024 * 1024);
    printf("[App] malloc(1MB) done, ptr = %p\n", p);
    printf("[App] Freeing memory via free(p)...\n");
    free(p);
    return 0;
}
