#include <stdio.h>
#include <sys/mman.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>

void sigsegv_handler(int sig) {
    printf("[Signal Handler] Caught SIGSEGV (%d)! MMU hardware check failed.\n", sig);
    exit(0);
}

int main() {
    signal(SIGSEGV, sigsegv_handler);

    int *page = (int*)mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
    *page = 42;
    printf("[App] Page allocated. Initial write: *page = %d\n", *page);

    printf("[App] Calling mprotect to set page PROT_READ (read-only)...\n");
    fflush(stdout);
    mprotect(page, 4096, PROT_READ);

    printf("[App] Writing to read-only page (will trigger MMU exception)...\n");
    fflush(stdout);
    *page = 100; // triggers hardware MMU exception

    return 0;
}
