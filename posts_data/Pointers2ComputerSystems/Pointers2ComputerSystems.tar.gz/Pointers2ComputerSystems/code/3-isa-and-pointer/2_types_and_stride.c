#include <stdint.h>

// 1. 访存指令位宽
int8_t  read_i8 (int8_t  *p) { return *p; }
int16_t read_i16(int16_t *p) { return *p; }
int32_t read_i32(int32_t *p) { return *p; }
int64_t read_i64(int64_t *p) { return *p; }

// 2. 指针步长计算
char*   step_char (char   *p) { return p + 1; }
int*    step_int  (int    *p) { return p + 1; }
int64_t* step_i64 (int64_t*p) { return p + 1; }
