int load_int(int *p) {
    return *p;
}

void store_int(int *p, int val) {
    *p = val;
}
