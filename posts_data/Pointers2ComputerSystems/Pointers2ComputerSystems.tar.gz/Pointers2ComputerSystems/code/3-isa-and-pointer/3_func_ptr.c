int target_func(int x);

int call_direct(int x) {
    int res = target_func(x);
    return res + 1;
}

int call_indirect(int (*fn)(int), int x) {
    int res = fn(x);
    return res + 1;
}
