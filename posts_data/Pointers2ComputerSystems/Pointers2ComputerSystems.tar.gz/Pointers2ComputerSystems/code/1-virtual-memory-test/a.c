#include <stdint.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>

#define ESCAPE_CODE "\x1b[31m"
#define log_printf(fmt, ...) do { printf(ESCAPE_CODE fmt "\x1b[0m", ##__VA_ARGS__); fflush(stdout); } while(0)

void* base_addr = (void*)(0x800000);

int main() {
    setvbuf(stdout, NULL, _IONBF, 0); // 关闭标准输出流缓冲，确保并发日志即时刷新
    FILE* fp = fopen("./a.txt", "r+");
    int *a = (int*)mmap(base_addr, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, fileno(fp), 0);
    fclose(fp);

    log_printf("[a.exe] a = %p\n", a);
    log_printf("[a.exe] a[]:");
    for (int i = 0; i < 10; i++) {
        a[i] = i * i;
        log_printf("%4d", a[i]);
    }
    putchar('\n');
    
    log_printf("[a.exe] sleep 1 sec...\n");
    sleep(1);
    
    log_printf("[a.exe] a[]:");
    for (int i = 0; i < 10; i++) {
        log_printf("%4d", a[i]);
    }
    putchar('\n');

    return 0;
}
